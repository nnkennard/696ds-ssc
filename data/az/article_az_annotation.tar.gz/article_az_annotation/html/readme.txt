The 50 articles have been selected from the following journals:

BMC Public Health		1
Carcinogenesis			16
Chem Res Toxicol		2
Environ Health Perspect		18
J Biol Chem			3
Occup Environ Med		1
PLoS One			1
Toxicological Sciences		8
